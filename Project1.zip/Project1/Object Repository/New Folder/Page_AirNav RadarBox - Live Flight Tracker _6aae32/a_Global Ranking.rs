<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Global Ranking</name>
   <tag></tag>
   <elementGuidId>fded772b-b80b-436c-be00-0a23e8fe5355</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Global Ranking')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Global Ranking&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>055a3d5f-863e-4907-967c-79c92f6e5fd0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ListItemLabel</value>
      <webElementGuid>be68ef32-bad2-43cd-962f-25132b8b11bc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/stations</value>
      <webElementGuid>7d2a2814-eaa3-4b95-b5d7-723c0e642e7a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Global Ranking</value>
      <webElementGuid>52af9df2-4278-4d26-99d9-565c6cc2591b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;pr-cons full-screen-map bottomMenu&quot;]/header[1]/div[@class=&quot;sc-PZstE cvXkni transparent&quot;]/nav[@class=&quot;sc-DtlDN jjyQap&quot;]/ul[@class=&quot;sc-iJKOzS iWqaTP List CollapsibleList ListWithSeparators&quot;]/li[@class=&quot;sc-1r60hsm-0 fGkvnU ListItem sc-5meb5d-0 hEAeUN top-level NavigationMenuListItem ListItemSelected ListItemClickable&quot;]/div[@class=&quot;CollapsibleListItem-content&quot;]/ul[@class=&quot;sc-iJKOzS iWqaTP List CollapsibleList&quot;]/li[@class=&quot;sc-cxpRKc bReyzf ListItem NavigationMenuListItem ListItemClickable&quot;]/a[@class=&quot;ListItemLabel&quot;]</value>
      <webElementGuid>462dad96-49fa-4276-aca8-ea85f04efa6f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Global Ranking')]</value>
      <webElementGuid>b7e2277a-8efa-4181-9802-988e8bc60059</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='GPS Accuracy'])[1]/following::a[1]</value>
      <webElementGuid>52259166-d684-43ce-a689-fb4e67454979</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Coverage Map'])[1]/following::a[2]</value>
      <webElementGuid>97b27c19-a70f-4169-97c2-ef1efee3b62a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='New Units'])[1]/preceding::a[1]</value>
      <webElementGuid>7fe79b29-f3b4-4762-b00d-50ffb95444f5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='VHF Units'])[1]/preceding::a[2]</value>
      <webElementGuid>09712caa-cc12-4ca9-87f6-a6868db38dd8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Global Ranking']/parent::*</value>
      <webElementGuid>3c7e2f76-ac3f-4a12-991a-2e73ce94cb75</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/stations')]</value>
      <webElementGuid>54122bcc-4737-42a1-b5d0-ad39098ef989</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[3]/div[2]/ul/li[3]/a</value>
      <webElementGuid>cbd2c58f-ea20-41ad-8e44-13d9fdfd6b86</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/stations' and (text() = 'Global Ranking' or . = 'Global Ranking')]</value>
      <webElementGuid>ea65c653-ac00-4734-978a-64c7744cc6ed</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
