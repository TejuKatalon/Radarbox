<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Flight Tracking</name>
   <tag></tag>
   <elementGuidId>17cbe158-c985-4a33-ac7e-0225b49e2fcd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='FlightWatch'])[1]/following::span[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Flight Tracking&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>b844886c-9e44-40a2-96d7-95fb01ccbab9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Flight Tracking</value>
      <webElementGuid>bf45315c-476d-4d89-bce1-901eb44388fa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;pr-cons full-screen-map bottomMenu&quot;]/header[1]/div[@class=&quot;sc-dGXzYd gcPYbK transparent&quot;]/nav[@class=&quot;sc-iukwUI ivbYHr&quot;]/ul[@class=&quot;sc-iJKOzS iWqaTP List CollapsibleList ListWithSeparators&quot;]/li[@class=&quot;sc-cxpRKc bReyzf ListItem sc-eGRTUG kOYuEr top-level NavigationMenuListItem ListItemClickable&quot;]/div[@class=&quot;CollapsibleListItem-content&quot;]/ul[@class=&quot;sc-iJKOzS iWqaTP List CollapsibleList&quot;]/li[@class=&quot;sc-cxpRKc bReyzf ListItem sc-eGRTUG kOYuEr NavigationMenuListItem ListItemClickable&quot;]/div[@class=&quot;ListItemLabel&quot;]/span[1]</value>
      <webElementGuid>3c17ef59-bdaf-41a2-b3f2-bc92801e21d6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FlightWatch'])[1]/following::span[1]</value>
      <webElementGuid>0d725bcc-7ba9-4877-b2a0-f6dbbc263fdf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Flight Data'])[1]/following::span[1]</value>
      <webElementGuid>d4803426-9608-44a4-b612-9504e01e4703</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Overview'])[2]/preceding::span[1]</value>
      <webElementGuid>cc5d12cb-51e8-48a4-9532-307ab07e5d3c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Fleet Tracker'])[1]/preceding::span[1]</value>
      <webElementGuid>7fba91a8-a076-4bd3-a71f-d5561a92d6a2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Flight Tracking']/parent::*</value>
      <webElementGuid>16c67af9-10ff-4885-ae64-306a1e291223</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/ul/li[6]/div/span</value>
      <webElementGuid>0ba3cf17-684a-4e07-8714-594bf52fbd09</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Flight Tracking' or . = 'Flight Tracking')]</value>
      <webElementGuid>38830c20-6a83-4437-925d-8a7c383669ca</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
