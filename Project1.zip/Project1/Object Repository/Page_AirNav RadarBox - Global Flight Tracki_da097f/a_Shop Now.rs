<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Shop Now</name>
   <tag></tag>
   <elementGuidId>a4d3c4d5-d7aa-4f37-b496-99256305f051</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.CollapsibleListItem-content > ul.sc-bBHwJV.jmanQO.List.CollapsibleList > li.sc-dlVyqM.hqodcB.ListItem.NavigationMenuListItem.ListItemClickable > a.ListItemLabel</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Shop Now')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Shop Now&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>6a47c821-5e07-44d7-9405-1817ec480f56</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ListItemLabel</value>
      <webElementGuid>75ce1b67-b741-4ca1-a119-e49498e7c76c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/store</value>
      <webElementGuid>e04c7f88-b0db-4655-b36f-f81d74ff7866</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Shop Now</value>
      <webElementGuid>357cf56c-66c2-47d4-ba91-51af00a436a0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;pr-cons full-screen-map bottomMenu&quot;]/header[1]/div[@class=&quot;sc-bilypg kbjQyn transparent&quot;]/nav[@class=&quot;sc-jObXwK dzYCnw&quot;]/ul[@class=&quot;sc-bBHwJV jmanQO List CollapsibleList ListWithSeparators&quot;]/li[@class=&quot;sc-1r60hsm-0 fGkvnU ListItem sc-5meb5d-0 hEAeUN top-level NavigationMenuListItem ListItemSelected ListItemClickable&quot;]/div[@class=&quot;CollapsibleListItem-content&quot;]/ul[@class=&quot;sc-bBHwJV jmanQO List CollapsibleList&quot;]/li[@class=&quot;sc-1r60hsm-0 fGkvnU ListItem sc-5meb5d-0 hEAeUN NavigationMenuListItem ListItemSelected ListItemClickable&quot;]/div[@class=&quot;CollapsibleListItem-content&quot;]/ul[@class=&quot;sc-bBHwJV jmanQO List CollapsibleList&quot;]/li[@class=&quot;sc-dlVyqM hqodcB ListItem NavigationMenuListItem ListItemClickable&quot;]/a[@class=&quot;ListItemLabel&quot;]</value>
      <webElementGuid>c6689c5e-f172-4e9c-b0df-87679505b352</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Shop Now')]</value>
      <webElementGuid>d2690db9-bd86-4f2c-9321-c98368cca725</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Store'])[1]/following::a[1]</value>
      <webElementGuid>2a487687-ce58-44a7-a6b8-d7e8912972c6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Solutions'])[1]/following::a[1]</value>
      <webElementGuid>e41b6a79-10f2-46e8-b397-939decefeb64</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Overview'])[1]/preceding::a[1]</value>
      <webElementGuid>a2d703ff-1131-44e2-a45e-11b62a90b27e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FlightStick 1090'])[1]/preceding::a[2]</value>
      <webElementGuid>7aad4d17-5abb-40be-a0f2-9950d262d1b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Shop Now']/parent::*</value>
      <webElementGuid>c3238302-53c9-4d48-903a-5503750061ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/store')]</value>
      <webElementGuid>a4031a89-9d24-4c36-81e7-f2bc53c16f25</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/ul/li/div[2]/ul/li/a</value>
      <webElementGuid>bb77fc68-cd0d-4a6d-8570-745d8f475830</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/store' and (text() = 'Shop Now' or . = 'Shop Now')]</value>
      <webElementGuid>e50bdd0d-ae65-4677-8d4e-c626012eb30a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
