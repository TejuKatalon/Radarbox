<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Airport View</name>
   <tag></tag>
   <elementGuidId>52651e93-9be4-47b4-8665-54b9a743b2f5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Airport View')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Airport View&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>8e544261-ec90-4c0f-a7ba-9b0eba97b0ca</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ListItemLabel</value>
      <webElementGuid>a6657f38-ffaf-4749-aa81-ab6e8956b8fa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/business/airport-view</value>
      <webElementGuid>7fde4a5c-aa06-4fe9-a187-0aae0ca12142</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Airport View</value>
      <webElementGuid>63c7c149-9dc8-41e5-bdc7-bec7b7010e10</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;pr-cons full-screen-map bottomMenu&quot;]/header[1]/div[@class=&quot;sc-gIDmry bHDIwW transparent&quot;]/nav[@class=&quot;sc-gWXaA-D czklOi&quot;]/ul[@class=&quot;sc-jrQzUz kWQGNZ List CollapsibleList ListWithSeparators&quot;]/li[@class=&quot;sc-iCfLBT iXtNqU ListItem sc-furvIG fteEHs top-level NavigationMenuListItem ListItemClickable&quot;]/div[@class=&quot;CollapsibleListItem-content&quot;]/ul[@class=&quot;sc-jrQzUz kWQGNZ List CollapsibleList&quot;]/li[@class=&quot;sc-1r60hsm-0 fGkvnU ListItem sc-5meb5d-0 hEAeUN NavigationMenuListItem ListItemSelected ListItemClickable&quot;]/div[@class=&quot;CollapsibleListItem-content&quot;]/ul[@class=&quot;sc-jrQzUz kWQGNZ List CollapsibleList&quot;]/li[@class=&quot;sc-iCfLBT iXtNqU ListItem NavigationMenuListItem ListItemClickable&quot;]/a[@class=&quot;ListItemLabel&quot;]</value>
      <webElementGuid>5bcdc826-39d7-4840-9d3a-1bc367923987</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Airport View')]</value>
      <webElementGuid>34e47800-db3f-4a3a-b317-7f0c243479f8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Fleet Tracker'])[1]/following::a[1]</value>
      <webElementGuid>c1900a1b-16d0-47eb-9466-87e68c2d62b3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Overview'])[2]/following::a[2]</value>
      <webElementGuid>2ed20e20-fe89-49db-af31-e818e9ac68f8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ADS-B Hardware'])[1]/preceding::a[1]</value>
      <webElementGuid>20944f22-fa2a-4209-913c-b2793a4c0729</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ADS-B Derived Weather'])[1]/preceding::a[2]</value>
      <webElementGuid>694b31cf-850f-4707-b28b-d34db629184d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Airport View']/parent::*</value>
      <webElementGuid>bdec87bb-b238-49f1-ba50-20251abc4a28</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/business/airport-view')]</value>
      <webElementGuid>482286b8-b1dc-4c51-bdb5-f973b53de140</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[6]/div[2]/ul/li[4]/a</value>
      <webElementGuid>0a877d89-c23b-469c-815e-ed2a88b3e484</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/business/airport-view' and (text() = 'Airport View' or . = 'Airport View')]</value>
      <webElementGuid>57cb0b51-3b31-4dab-802e-dabd22b43cc5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
