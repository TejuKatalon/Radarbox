<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Flight Tracking</name>
   <tag></tag>
   <elementGuidId>0735cd6e-4aff-4b71-80eb-9b7d60af9daa</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='FlightWatch'])[1]/following::span[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Flight Tracking&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>684150da-e67e-45ed-a55f-14799832673e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Flight Tracking</value>
      <webElementGuid>c5cbf88a-7cbe-45b0-8ed0-358edf762718</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;pr-cons full-screen-map bottomMenu&quot;]/header[1]/div[@class=&quot;sc-gIDmry bHDIwW transparent&quot;]/nav[@class=&quot;sc-gWXaA-D czklOi&quot;]/ul[@class=&quot;sc-jrQzUz kWQGNZ List CollapsibleList ListWithSeparators&quot;]/li[@class=&quot;sc-iCfLBT iXtNqU ListItem sc-furvIG fteEHs top-level NavigationMenuListItem ListItemClickable&quot;]/div[@class=&quot;CollapsibleListItem-content&quot;]/ul[@class=&quot;sc-jrQzUz kWQGNZ List CollapsibleList&quot;]/li[@class=&quot;sc-iCfLBT iXtNqU ListItem sc-furvIG fteEHs NavigationMenuListItem ListItemClickable&quot;]/div[@class=&quot;ListItemLabel&quot;]/span[1]</value>
      <webElementGuid>213af6fb-daa9-4d61-b3ad-b5fc3ead299a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FlightWatch'])[1]/following::span[1]</value>
      <webElementGuid>714a21d7-efbe-4b86-8997-dcf87dcc5972</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Flight Data'])[1]/following::span[1]</value>
      <webElementGuid>8f3fca76-9ba0-4f7c-a2d3-d88298e0a5d6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Overview'])[2]/preceding::span[1]</value>
      <webElementGuid>4f0068d4-b1cd-408a-ba1a-e6af1e1cccc2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Fleet Tracker'])[1]/preceding::span[1]</value>
      <webElementGuid>af2ec5d8-a4ae-4c74-bd38-9e007d862ca1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Flight Tracking']/parent::*</value>
      <webElementGuid>a790ffbb-cb38-48c9-ab37-cb9383df71a0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/ul/li[6]/div/span</value>
      <webElementGuid>f6fd22f5-3d25-497e-a457-aa86b135dcf3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Flight Tracking' or . = 'Flight Tracking')]</value>
      <webElementGuid>f20e2c31-612d-48c6-a6cb-57b194698903</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
