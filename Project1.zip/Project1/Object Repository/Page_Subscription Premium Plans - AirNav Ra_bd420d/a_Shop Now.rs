<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Shop Now</name>
   <tag></tag>
   <elementGuidId>7d09a416-9812-447b-8d2f-c953c55418b3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.CollapsibleListItem-content > ul.sc-hBURRC.kQUxvR.List.CollapsibleList > li.sc-egiSv.hZbsoo.ListItem.NavigationMenuListItem.ListItemClickable > a.ListItemLabel</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Shop Now')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Shop Now&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>b4bb915d-52b9-41dc-b09b-b991e698b383</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ListItemLabel</value>
      <webElementGuid>60e35eb7-c5fd-45ac-8e37-fd7099376117</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/store</value>
      <webElementGuid>0cac8411-1ba8-4449-b2c5-11d88d62f317</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Shop Now</value>
      <webElementGuid>b6c248b6-3a7a-44fc-9dcd-a2c24997374d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;pr-cons&quot;]/header[1]/div[@class=&quot;sc-XxOsz sQArU&quot;]/nav[@class=&quot;sc-iAKVOt gwzDgV&quot;]/ul[@class=&quot;sc-hBURRC kQUxvR List CollapsibleList ListWithSeparators&quot;]/li[@class=&quot;sc-1r60hsm-0 fGkvnU ListItem sc-5meb5d-0 hEAeUN top-level NavigationMenuListItem ListItemSelected ListItemClickable&quot;]/div[@class=&quot;CollapsibleListItem-content&quot;]/ul[@class=&quot;sc-hBURRC kQUxvR List CollapsibleList&quot;]/li[@class=&quot;sc-1r60hsm-0 fGkvnU ListItem sc-5meb5d-0 hEAeUN NavigationMenuListItem ListItemSelected ListItemClickable&quot;]/div[@class=&quot;CollapsibleListItem-content&quot;]/ul[@class=&quot;sc-hBURRC kQUxvR List CollapsibleList&quot;]/li[@class=&quot;sc-egiSv hZbsoo ListItem NavigationMenuListItem ListItemClickable&quot;]/a[@class=&quot;ListItemLabel&quot;]</value>
      <webElementGuid>45cbb23b-7913-4e3f-b8c8-b2860fe76468</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Shop Now')]</value>
      <webElementGuid>a177f2da-7768-4a79-9167-ba4fc112d45d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Store'])[1]/following::a[1]</value>
      <webElementGuid>2db71656-d2c1-4b4d-a026-4f8abb1018dc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Solutions'])[1]/following::a[1]</value>
      <webElementGuid>d74928aa-1cb2-477f-895c-9a9ac44c3188</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Overview'])[1]/preceding::a[1]</value>
      <webElementGuid>60b5d741-3a7a-401c-8423-9d9fc290f4c2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FlightStick 1090'])[1]/preceding::a[2]</value>
      <webElementGuid>6a7684ca-a81b-45cb-869a-89bc9d20ac44</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Shop Now']/parent::*</value>
      <webElementGuid>785fdbdf-f8bf-4041-a5cf-608d84346579</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/store')]</value>
      <webElementGuid>6dfd0d90-1d4e-4713-9873-259842f3d2f2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/ul/li/div[2]/ul/li/a</value>
      <webElementGuid>fbe46a99-2816-481c-a9e0-bf3900584521</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/store' and (text() = 'Shop Now' or . = 'Shop Now')]</value>
      <webElementGuid>330e3d02-9d17-4868-8d1f-54b6095ed636</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
