<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Store</name>
   <tag></tag>
   <elementGuidId>d8be9fb7-8634-43f7-a611-ff041c0d8df5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.sc-egiSv.hZbsoo.ListItem.sc-bqiQRQ.imPtOh.NavigationMenuListItem.ListItemClickable > div.ListItemLabel > span</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Solutions'])[1]/following::span[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=banner >> internal:text=&quot;Store&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>cd8693b0-f869-4977-a468-24e2548008e5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Store</value>
      <webElementGuid>70fa59b4-bf2d-4d60-8ffb-7ff72aa41426</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;pr-cons&quot;]/header[1]/div[@class=&quot;sc-XxOsz sQArU&quot;]/nav[@class=&quot;sc-iAKVOt gwzDgV&quot;]/ul[@class=&quot;sc-hBURRC kQUxvR List CollapsibleList ListWithSeparators&quot;]/li[@class=&quot;sc-1r60hsm-0 fGkvnU ListItem sc-5meb5d-0 hEAeUN top-level NavigationMenuListItem ListItemSelected ListItemClickable&quot;]/div[@class=&quot;CollapsibleListItem-content&quot;]/ul[@class=&quot;sc-hBURRC kQUxvR List CollapsibleList&quot;]/li[@class=&quot;sc-egiSv hZbsoo ListItem sc-bqiQRQ imPtOh NavigationMenuListItem ListItemClickable&quot;]/div[@class=&quot;ListItemLabel&quot;]/span[1]</value>
      <webElementGuid>01617c1e-b778-43eb-913c-38c106b39e94</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Solutions'])[1]/following::span[1]</value>
      <webElementGuid>256f0d51-2508-4c0d-b22b-2d7995f9c3be</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Subscriptions'])[1]/following::span[2]</value>
      <webElementGuid>2e77f0b0-c5fd-436a-8190-d28f04ca6aab</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Shop Now'])[1]/preceding::span[1]</value>
      <webElementGuid>73c52dc4-7b00-4062-9a10-1ed4ddce1d9e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Overview'])[1]/preceding::span[1]</value>
      <webElementGuid>145d5d96-ebd2-4528-8de2-f49bc8047ca8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Store']/parent::*</value>
      <webElementGuid>67e0d00a-ffd4-4576-892c-42502a798d98</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/ul/li/div/span</value>
      <webElementGuid>3874b0c4-d1f5-40f9-ad7c-01db53c824e1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Store' or . = 'Store')]</value>
      <webElementGuid>a4ad6157-94a9-4cd8-a3f0-ee6414fa9b80</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
