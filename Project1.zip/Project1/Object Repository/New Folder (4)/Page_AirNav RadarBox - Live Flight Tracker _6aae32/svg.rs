<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>svg</name>
   <tag></tag>
   <elementGuidId>f1365b38-e5fd-48c9-ad40-3777b22c5472</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#splash-close-container > svg</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Media'])[1]/following::*[name()='svg'][1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#splash-close-container >> internal:role=img</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>svg</value>
      <webElementGuid>0ee0a0c6-c498-400b-a0e6-d5931c354056</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>viewBox</name>
      <type>Main</type>
      <value>0 0 14 14</value>
      <webElementGuid>b7405d41-e45f-4ea0-af76-36d872bb0f75</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;splash-close-container&quot;)/svg[1]</value>
      <webElementGuid>72d001a0-97fb-48ca-b5b0-3aeabbd1dc6e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Media'])[1]/following::*[name()='svg'][1]</value>
      <webElementGuid>1044408b-6b68-4c99-a5a8-57937e1e7bb4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='learn more'])[1]/following::*[name()='svg'][3]</value>
      <webElementGuid>e44d005f-baeb-4112-8fcb-2473d1467b94</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
