<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Airport View</name>
   <tag></tag>
   <elementGuidId>a61406bd-3c30-4355-951f-5fed1d0a9ddf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Airport View')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Airport View&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>fec8b9c8-b48e-4174-a8bc-2bb9844b272b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ListItemLabel</value>
      <webElementGuid>7167b7e1-de24-4453-8551-369379ebcc8a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/business/airport-view</value>
      <webElementGuid>32e6799d-89dc-4a1c-9fed-39d15de8ddb7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Airport View</value>
      <webElementGuid>0196b799-a25a-49e5-9219-853d02b3a72f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;pr-cons full-screen-map bottomMenu&quot;]/header[1]/div[@class=&quot;sc-dGXzYd gcPYbK transparent&quot;]/nav[@class=&quot;sc-iukwUI ivbYHr&quot;]/ul[@class=&quot;sc-iJKOzS iWqaTP List CollapsibleList ListWithSeparators&quot;]/li[@class=&quot;sc-1r60hsm-0 fGkvnU ListItem sc-5meb5d-0 hEAeUN top-level NavigationMenuListItem ListItemSelected ListItemClickable&quot;]/div[@class=&quot;CollapsibleListItem-content&quot;]/ul[@class=&quot;sc-iJKOzS iWqaTP List CollapsibleList&quot;]/li[@class=&quot;sc-1r60hsm-0 fGkvnU ListItem sc-5meb5d-0 hEAeUN NavigationMenuListItem ListItemSelected ListItemClickable&quot;]/div[@class=&quot;CollapsibleListItem-content&quot;]/ul[@class=&quot;sc-iJKOzS iWqaTP List CollapsibleList&quot;]/li[@class=&quot;sc-cxpRKc bReyzf ListItem NavigationMenuListItem ListItemClickable&quot;]/a[@class=&quot;ListItemLabel&quot;]</value>
      <webElementGuid>6e1f11f7-91ab-4c42-ba8a-ca8544f9e30d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Airport View')]</value>
      <webElementGuid>796bdfe9-054c-4a36-974f-b856daac5aa1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Fleet Tracker'])[1]/following::a[1]</value>
      <webElementGuid>583c065e-3e23-4029-aa1d-81edec7cccd0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Overview'])[2]/following::a[2]</value>
      <webElementGuid>ab606e5b-d887-4465-be28-7e529e036a82</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ADS-B Hardware'])[1]/preceding::a[1]</value>
      <webElementGuid>58d643d9-cde5-4020-9e1f-83bd6861502d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ADS-B Derived Weather'])[1]/preceding::a[2]</value>
      <webElementGuid>a1e39c7d-645a-464d-a613-9a0514a56143</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Airport View']/parent::*</value>
      <webElementGuid>3fc02266-bb4f-4253-9e62-083bc993c95b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/business/airport-view')]</value>
      <webElementGuid>406eccf8-82ef-436d-879a-9f7020d547d4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[6]/div[2]/ul/li[4]/a</value>
      <webElementGuid>ff2683a0-057e-4a3d-9bfb-ead6689bff64</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/business/airport-view' and (text() = 'Airport View' or . = 'Airport View')]</value>
      <webElementGuid>20e98724-b40c-48b5-a50a-412faa36fa10</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
