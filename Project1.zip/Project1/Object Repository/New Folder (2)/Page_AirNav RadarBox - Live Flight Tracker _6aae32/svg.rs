<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>svg</name>
   <tag></tag>
   <elementGuidId>ba387249-fff8-446d-9096-78e43ea8202e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#splash-close-container > svg</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Media'])[1]/following::*[name()='svg'][1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#splash-close-container >> internal:role=img</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>svg</value>
      <webElementGuid>f1d4340e-e028-4e92-b237-dec84eab159e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>viewBox</name>
      <type>Main</type>
      <value>0 0 14 14</value>
      <webElementGuid>236e5d61-b2dd-41c9-8fc3-d5cd31bce070</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;splash-close-container&quot;)/svg[1]</value>
      <webElementGuid>b284547b-64f6-4ca3-bf50-3e746a72c94c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Media'])[1]/following::*[name()='svg'][1]</value>
      <webElementGuid>bf16ae4f-4de1-4705-bb37-eb31e19393fe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='learn more'])[1]/following::*[name()='svg'][3]</value>
      <webElementGuid>17a00755-806d-4331-a2cd-84b3485a3d3d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
